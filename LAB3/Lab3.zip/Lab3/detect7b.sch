VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtex2p"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1(111:0)
        SIGNAL pipe1(71:0)
        SIGNAL clk
        SIGNAL XLXN_4
        SIGNAL match
        SIGNAL XLXN_6
        SIGNAL match_en
        SIGNAL XLXN_11
        SIGNAL mrst
        SIGNAL pipe0(47:0)
        SIGNAL pipe1(63:0)
        SIGNAL ce
        SIGNAL pipe0(71:0)
        SIGNAL hwregA(55:0)
        SIGNAL hwregA(62:56)
        SIGNAL hwregA(62:0)
        PORT Input pipe1(71:0)
        PORT Input clk
        PORT Output match
        PORT Input match_en
        PORT Input mrst
        PORT Input ce
        PORT Input hwregA(62:0)
        BEGIN BLOCKDEF BusMerge
            TIMESTAMP 2026 1 31 23 49 48
            RECTANGLE N 64 -128 320 0 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -96 384 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF wordmatch
            TIMESTAMP 2026 1 31 22 58 13
            RECTANGLE N 64 -192 320 0 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 320 -160 384 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF reg9b
            TIMESTAMP 2026 1 31 23 47 48
            RECTANGLE N 64 -256 320 0 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -236 384 -212 
            LINE N 320 -224 384 -224 
        END BLOCKDEF
        BEGIN BLOCKDEF fd
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -320 320 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF fdce
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 64 -112 80 -128 
            LINE N 80 -128 64 -144 
            LINE N 192 -64 192 -32 
            LINE N 192 -32 64 -32 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF and3b1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 40 -64 
            CIRCLE N 40 -76 64 -52 
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 256 -128 192 -128 
            LINE N 64 -64 64 -192 
            ARC N 96 -176 192 -80 144 -80 144 -176 
            LINE N 144 -80 64 -80 
            LINE N 64 -176 144 -176 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 BusMerge
            PIN da(47:0) pipe0(47:0)
            PIN db(63:0) pipe1(63:0)
            PIN q(111:0) XLXN_1(111:0)
        END BLOCK
        BEGIN BLOCK XLXI_2 wordmatch
            PIN datacomp(55:0) hwregA(55:0)
            PIN wildcard(6:0) hwregA(62:56)
            PIN datain(111:0) XLXN_1(111:0)
            PIN match XLXN_4
        END BLOCK
        BEGIN BLOCK XLXI_3 reg9b
            PIN d(71:0) pipe1(71:0)
            PIN clr XLXN_11
            PIN ce ce
            PIN clk clk
            PIN q(71:0) pipe0(71:0)
        END BLOCK
        BEGIN BLOCK XLXI_4 fd
            PIN C clk
            PIN D mrst
            PIN Q XLXN_11
        END BLOCK
        BEGIN BLOCK XLXI_5 fdce
            PIN C clk
            PIN CE XLXN_6
            PIN CLR XLXN_11
            PIN D XLXN_6
            PIN Q match
        END BLOCK
        BEGIN BLOCK XLXI_6 and3b1
            PIN I0 match
            PIN I1 match_en
            PIN I2 XLXN_4
            PIN O XLXN_6
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN INSTANCE XLXI_1 320 1136 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_2 912 1072 R0
        END INSTANCE
        BEGIN BRANCH XLXN_1(111:0)
            WIRE 704 1040 912 1040
        END BRANCH
        BEGIN INSTANCE XLXI_3 224 688 R0
        END INSTANCE
        BEGIN BRANCH pipe1(71:0)
            WIRE 160 464 224 464
        END BRANCH
        IOMARKER 160 464 pipe1(71:0) R180 28
        BEGIN BRANCH clk
            WIRE 160 656 176 656
            WIRE 176 656 224 656
            WIRE 176 656 176 1600
            WIRE 176 1600 1200 1600
            WIRE 1200 1600 1232 1600
            WIRE 1200 1600 1200 1728
            WIRE 1200 1728 1664 1728
            WIRE 1664 1040 1664 1728
            WIRE 1664 1040 1680 1040
        END BRANCH
        INSTANCE XLXI_5 1680 1168 R0
        INSTANCE XLXI_4 1232 1728 R0
        BEGIN BRANCH XLXN_4
            WIRE 1296 912 1328 912
        END BRANCH
        INSTANCE XLXI_6 1328 1104 R0
        BEGIN BRANCH match
            WIRE 1328 1040 1328 1200
            WIRE 1328 1200 2144 1200
            WIRE 2064 912 2144 912
            WIRE 2144 912 2144 1200
            WIRE 2144 912 2240 912
        END BRANCH
        IOMARKER 2240 912 match R0 28
        BEGIN BRANCH XLXN_6
            WIRE 1584 976 1632 976
            WIRE 1632 976 1680 976
            WIRE 1632 912 1632 976
            WIRE 1632 912 1680 912
        END BRANCH
        BEGIN BRANCH match_en
            WIRE 1056 1152 1312 1152
            WIRE 1312 976 1312 1152
            WIRE 1312 976 1328 976
        END BRANCH
        IOMARKER 1056 1152 match_en R180 28
        BEGIN BRANCH XLXN_11
            WIRE 208 528 224 528
            WIRE 208 528 208 1792
            WIRE 208 1792 1680 1792
            WIRE 1616 1472 1680 1472
            WIRE 1680 1472 1680 1792
            WIRE 1680 1136 1680 1472
        END BRANCH
        BEGIN BRANCH mrst
            WIRE 1168 1472 1232 1472
        END BRANCH
        IOMARKER 1168 1472 mrst R180 28
        BEGIN BRANCH pipe0(47:0)
            WIRE 240 1040 320 1040
            BEGIN DISPLAY 240 1040 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH pipe1(63:0)
            WIRE 240 1104 320 1104
            BEGIN DISPLAY 240 1104 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ce
            WIRE 160 592 224 592
        END BRANCH
        IOMARKER 160 656 clk R180 28
        IOMARKER 160 592 ce R180 28
        BEGIN BRANCH pipe0(71:0)
            WIRE 608 464 688 464
            BEGIN DISPLAY 688 464 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH hwregA(55:0)
            WIRE 864 912 912 912
            BEGIN DISPLAY 864 912 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH hwregA(62:56)
            WIRE 848 976 912 976
            BEGIN DISPLAY 848 976 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        IOMARKER 384 96 hwregA(62:0) R180 28
        BEGIN BRANCH hwregA(62:0)
            WIRE 384 96 496 96
        END BRANCH
    END SHEET
END SCHEMATIC
