////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 1995-2008 Xilinx, Inc.  All rights reserved.
////////////////////////////////////////////////////////////////////////////////
//   ____  ____ 
//  /   /\/   / 
// /___/  \  /    Vendor: Xilinx 
// \   \   \/     Version : 10.1
//  \   \         Application : sch2verilog
//  /   /         Filename : detect7b.vf
// /___/   /\     Timestamp : 01/31/2026 18:15:05
// \   \  /  \ 
//  \___\/\___\ 
//
//Command: C:\Xilinx\10.1\ISE\bin\nt\unwrapped\sch2verilog.exe -intstyle ise -family virtex2p -w "C:/Documents and Settings/All Users/Documents/Lab2/Lab2/Lab3/detect7b.sch" detect7b.vf
//Design Name: detect7b
//Device: virtex2p
//Purpose:
//    This verilog netlist is translated from an ECS schematic.It can be 
//    synthesized and simulated, but it should not be modified. 
//
`timescale 1ns / 1ps

module detect7b(ce, 
                clk, 
                hwregA, 
                match_en, 
                mrst, 
                pipe1, 
                match);

    input ce;
    input clk;
    input [62:0] hwregA;
    input match_en;
    input mrst;
    input [71:0] pipe1;
   output match;
   
   wire [71:0] pipe0;
   wire [111:0] XLXN_1;
   wire XLXN_4;
   wire XLXN_6;
   wire XLXN_11;
   wire match_DUMMY;
   
   assign match = match_DUMMY;
   BusMerge XLXI_1 (.da(pipe0[47:0]), 
                    .db(pipe1[63:0]), 
                    .q(XLXN_1[111:0]));
   wordmatch XLXI_2 (.datacomp(hwregA[55:0]), 
                     .datain(XLXN_1[111:0]), 
                     .wildcard(hwregA[62:56]), 
                     .match(XLXN_4));
   reg9b XLXI_3 (.ce(ce), 
                 .clk(clk), 
                 .clr(XLXN_11), 
                 .d(pipe1[71:0]), 
                 .q(pipe0[71:0]));
   FD XLXI_4 (.C(clk), 
              .D(mrst), 
              .Q(XLXN_11));
   defparam XLXI_4.INIT = 1'b0;
   FDCE XLXI_5 (.C(clk), 
                .CE(XLXN_6), 
                .CLR(XLXN_11), 
                .D(XLXN_6), 
                .Q(match_DUMMY));
   defparam XLXI_5.INIT = 1'b0;
   AND3B1 XLXI_6 (.I0(match_DUMMY), 
                  .I1(match_en), 
                  .I2(XLXN_4), 
                  .O(XLXN_6));
endmodule
