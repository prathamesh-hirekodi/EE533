VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtex2p"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL d(71:0)
        SIGNAL q(71:0)
        SIGNAL clr
        SIGNAL ce
        SIGNAL clk
        SIGNAL q(15:0)
        SIGNAL q(63:48)
        SIGNAL q(47:32)
        SIGNAL q(31:16)
        SIGNAL d(71:64)
        SIGNAL d(63:48)
        SIGNAL d(47:32)
        SIGNAL d(31:16)
        SIGNAL d(15:0)
        SIGNAL q(71:64)
        PORT Input d(71:0)
        PORT Output q(71:0)
        PORT Input clr
        PORT Input ce
        PORT Input clk
        BEGIN BLOCKDEF fd16ce
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            RECTANGLE N 320 -268 384 -244 
            RECTANGLE N 0 -268 64 -244 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF fd8ce
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            RECTANGLE N 320 -268 384 -244 
            RECTANGLE N 0 -268 64 -244 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 fd16ce
            PIN C clk
            PIN CE ce
            PIN CLR clr
            PIN D(15:0) d(63:48)
            PIN Q(15:0) q(63:48)
        END BLOCK
        BEGIN BLOCK XLXI_2 fd16ce
            PIN C clk
            PIN CE ce
            PIN CLR clr
            PIN D(15:0) d(47:32)
            PIN Q(15:0) q(47:32)
        END BLOCK
        BEGIN BLOCK XLXI_3 fd16ce
            PIN C clk
            PIN CE ce
            PIN CLR clr
            PIN D(15:0) d(31:16)
            PIN Q(15:0) q(31:16)
        END BLOCK
        BEGIN BLOCK XLXI_4 fd16ce
            PIN C clk
            PIN CE ce
            PIN CLR clr
            PIN D(15:0) d(15:0)
            PIN Q(15:0) q(15:0)
        END BLOCK
        BEGIN BLOCK XLXI_5 fd8ce
            PIN C clk
            PIN CE ce
            PIN CLR clr
            PIN D(7:0) d(71:64)
            PIN Q(7:0) q(71:64)
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 1312 1024 R0
        INSTANCE XLXI_2 1296 1472 R0
        INSTANCE XLXI_3 1296 1888 R0
        INSTANCE XLXI_4 1280 2368 R0
        INSTANCE XLXI_5 1296 496 R0
        BEGIN BRANCH d(71:0)
            WIRE 816 2576 1008 2576
        END BRANCH
        BEGIN BRANCH q(71:0)
            WIRE 1328 2592 1600 2592
        END BRANCH
        IOMARKER 816 2576 d(71:0) R180 28
        IOMARKER 1328 2592 q(71:0) R180 28
        BEGIN BRANCH clr
            WIRE 960 2320 960 2336
            WIRE 960 2336 1056 2336
            WIRE 1056 2336 1280 2336
            WIRE 1056 464 1296 464
            WIRE 1056 464 1056 992
            WIRE 1056 992 1312 992
            WIRE 1056 992 1056 1440
            WIRE 1056 1440 1296 1440
            WIRE 1056 1440 1056 1856
            WIRE 1056 1856 1056 2336
            WIRE 1056 1856 1296 1856
        END BRANCH
        IOMARKER 848 2176 ce R180 28
        IOMARKER 960 2320 clr R270 28
        BEGIN BRANCH clk
            WIRE 832 2240 1168 2240
            WIRE 1168 2240 1280 2240
            WIRE 832 2240 832 2256
            WIRE 1168 368 1168 896
            WIRE 1168 896 1168 1344
            WIRE 1168 1344 1168 1760
            WIRE 1168 1760 1168 2240
            WIRE 1168 1760 1296 1760
            WIRE 1168 1344 1296 1344
            WIRE 1168 896 1312 896
            WIRE 1168 368 1296 368
        END BRANCH
        BEGIN BRANCH ce
            WIRE 848 2176 1216 2176
            WIRE 1216 2176 1280 2176
            WIRE 1216 304 1296 304
            WIRE 1216 304 1216 832
            WIRE 1216 832 1312 832
            WIRE 1216 832 1216 1280
            WIRE 1216 1280 1296 1280
            WIRE 1216 1280 1216 1696
            WIRE 1216 1696 1296 1696
            WIRE 1216 1696 1216 2176
        END BRANCH
        BEGIN BRANCH q(71:64)
            WIRE 1680 240 1792 240
            BEGIN DISPLAY 1792 240 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH q(63:48)
            WIRE 1696 768 1776 768
            BEGIN DISPLAY 1776 768 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH q(47:32)
            WIRE 1680 1216 1776 1216
            WIRE 1776 1216 1792 1216
            WIRE 1792 1216 1792 1232
            WIRE 1776 1232 1792 1232
            BEGIN DISPLAY 1776 1216 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH q(31:16)
            WIRE 1680 1632 1808 1632
            WIRE 1808 1632 1808 1648
            BEGIN DISPLAY 1808 1648 ATTR Name
                ALIGNMENT SOFT-VRIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH q(15:0)
            WIRE 1664 2112 1808 2112
            BEGIN DISPLAY 1808 2112 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH d(71:64)
            WIRE 1136 240 1296 240
            BEGIN DISPLAY 1136 240 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH d(63:48)
            WIRE 1120 768 1312 768
            BEGIN DISPLAY 1120 768 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH d(47:32)
            WIRE 1104 1216 1296 1216
            BEGIN DISPLAY 1104 1216 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH d(31:16)
            WIRE 1104 1632 1296 1632
            BEGIN DISPLAY 1104 1632 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH d(15:0)
            WIRE 1088 2112 1280 2112
            BEGIN DISPLAY 1088 2112 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        IOMARKER 832 2256 clk R90 28
    END SHEET
END SCHEMATIC
