VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtex2p"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL match
        SIGNAL XLXN_2
        SIGNAL XLXN_3
        SIGNAL XLXN_4
        SIGNAL XLXN_5
        SIGNAL XLXN_6
        SIGNAL XLXN_7
        SIGNAL XLXN_8
        SIGNAL XLXN_9
        SIGNAL datacomp(55:0)
        SIGNAL wildcard(6:0)
        SIGNAL datain(111:0)
        SIGNAL datain(55:0)
        SIGNAL datain(63:8)
        SIGNAL datain(79:24)
        SIGNAL datain(87:32)
        SIGNAL datain(95:40)
        SIGNAL datain(103:48)
        SIGNAL datain(111:56)
        PORT Output match
        PORT Input datacomp(55:0)
        PORT Input wildcard(6:0)
        PORT Input datain(111:0)
        BEGIN BLOCKDEF Comparator
            TIMESTAMP 2026 1 31 20 39 39
            RECTANGLE N 64 -192 320 0 
            RECTANGLE N 0 -172 64 -148 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 320 -160 384 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF or8
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 48 -64 
            LINE N 0 -128 48 -128 
            LINE N 0 -192 48 -192 
            LINE N 0 -384 48 -384 
            LINE N 0 -448 48 -448 
            LINE N 0 -512 48 -512 
            LINE N 256 -288 192 -288 
            LINE N 0 -320 64 -320 
            LINE N 0 -256 64 -256 
            ARC N 28 -336 204 -160 192 -288 112 -336 
            LINE N 112 -240 48 -240 
            ARC N 28 -416 204 -240 112 -240 192 -288 
            ARC N -40 -344 72 -232 48 -240 48 -336 
            LINE N 112 -336 48 -336 
            LINE N 48 -336 48 -512 
            LINE N 48 -64 48 -240 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 Comparator
            PIN a(55:0) datacomp(55:0)
            PIN b(55:0) datain(55:0)
            PIN amask(6:0) wildcard(6:0)
            PIN match XLXN_2
        END BLOCK
        BEGIN BLOCK XLXI_2 Comparator
            PIN a(55:0) datacomp(55:0)
            PIN b(55:0) datain(63:8)
            PIN amask(6:0) wildcard(6:0)
            PIN match XLXN_3
        END BLOCK
        BEGIN BLOCK XLXI_3 Comparator
            PIN a(55:0) datacomp(55:0)
            PIN b(55:0) datain(79:24)
            PIN amask(6:0) wildcard(6:0)
            PIN match XLXN_4
        END BLOCK
        BEGIN BLOCK XLXI_4 Comparator
            PIN a(55:0) datacomp(55:0)
            PIN b(55:0) datain(87:32)
            PIN amask(6:0) wildcard(6:0)
            PIN match XLXN_5
        END BLOCK
        BEGIN BLOCK XLXI_5 Comparator
            PIN a(55:0) datacomp(55:0)
            PIN b(55:0) datain(95:40)
            PIN amask(6:0) wildcard(6:0)
            PIN match XLXN_6
        END BLOCK
        BEGIN BLOCK XLXI_6 Comparator
            PIN a(55:0) datacomp(55:0)
            PIN b(55:0) datain(103:48)
            PIN amask(6:0) wildcard(6:0)
            PIN match XLXN_7
        END BLOCK
        BEGIN BLOCK XLXI_7 Comparator
            PIN a(55:0) datacomp(55:0)
            PIN b(55:0) datain(111:56)
            PIN amask(6:0) wildcard(6:0)
            PIN match XLXN_8
        END BLOCK
        BEGIN BLOCK XLXI_8 Comparator
            PIN a(55:0) datacomp(55:0)
            PIN b(55:0)
            PIN amask(6:0) wildcard(6:0)
            PIN match XLXN_9
        END BLOCK
        BEGIN BLOCK XLXI_9 or8
            PIN I0 XLXN_9
            PIN I1 XLXN_8
            PIN I2 XLXN_7
            PIN I3 XLXN_6
            PIN I4 XLXN_5
            PIN I5 XLXN_4
            PIN I6 XLXN_3
            PIN I7 XLXN_2
            PIN O match
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        BEGIN INSTANCE XLXI_1 816 272 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_2 816 576 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_3 816 880 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_4 816 1184 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_5 816 1488 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_6 816 1808 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_7 816 2128 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_8 816 2464 R0
        END INSTANCE
        INSTANCE XLXI_9 2016 1440 R0
        BEGIN BRANCH match
            WIRE 2272 1152 2432 1152
        END BRANCH
        IOMARKER 2432 1152 match R0 28
        BEGIN BRANCH XLXN_2
            WIRE 1200 112 2016 112
            WIRE 2016 112 2016 928
        END BRANCH
        BEGIN BRANCH XLXN_3
            WIRE 1200 416 1600 416
            WIRE 1600 416 1600 992
            WIRE 1600 992 2016 992
        END BRANCH
        BEGIN BRANCH XLXN_4
            WIRE 1200 720 1584 720
            WIRE 1584 720 1584 1056
            WIRE 1584 1056 2016 1056
        END BRANCH
        BEGIN BRANCH XLXN_5
            WIRE 1200 1024 1568 1024
            WIRE 1568 1024 1568 1120
            WIRE 1568 1120 2016 1120
        END BRANCH
        BEGIN BRANCH XLXN_6
            WIRE 1200 1328 1600 1328
            WIRE 1600 1184 1600 1328
            WIRE 1600 1184 2016 1184
        END BRANCH
        BEGIN BRANCH XLXN_7
            WIRE 1200 1648 1616 1648
            WIRE 1616 1248 1616 1648
            WIRE 1616 1248 2016 1248
        END BRANCH
        BEGIN BRANCH XLXN_8
            WIRE 1200 1968 1632 1968
            WIRE 1632 1312 1632 1968
            WIRE 1632 1312 2016 1312
        END BRANCH
        BEGIN BRANCH XLXN_9
            WIRE 1200 2304 2016 2304
            WIRE 2016 1376 2016 2304
        END BRANCH
        IOMARKER 256 80 datacomp(55:0) R180 28
        BEGIN BRANCH datacomp(55:0)
            WIRE 256 80 368 80
            WIRE 368 80 368 112
            WIRE 368 112 816 112
            WIRE 368 112 368 416
            WIRE 368 416 816 416
            WIRE 368 416 368 720
            WIRE 368 720 816 720
            WIRE 368 720 368 1024
            WIRE 368 1024 816 1024
            WIRE 368 1024 368 1328
            WIRE 368 1328 816 1328
            WIRE 368 1328 368 1648
            WIRE 368 1648 816 1648
            WIRE 368 1648 368 1968
            WIRE 368 1968 816 1968
            WIRE 368 1968 368 2304
            WIRE 368 2304 816 2304
        END BRANCH
        IOMARKER 336 240 wildcard(6:0) R180 28
        BEGIN BRANCH wildcard(6:0)
            WIRE 336 240 448 240
            WIRE 448 240 816 240
            WIRE 448 240 448 528
            WIRE 448 528 448 544
            WIRE 448 544 816 544
            WIRE 448 544 448 848
            WIRE 448 848 816 848
            WIRE 448 848 448 1152
            WIRE 448 1152 816 1152
            WIRE 448 1152 448 1456
            WIRE 448 1456 816 1456
            WIRE 448 1456 448 1760
            WIRE 448 1760 448 1776
            WIRE 448 1776 816 1776
            WIRE 448 1776 448 2096
            WIRE 448 2096 816 2096
            WIRE 448 2096 448 2432
            WIRE 448 2432 816 2432
        END BRANCH
        BEGIN BRANCH datain(55:0)
            WIRE 752 176 816 176
            BEGIN DISPLAY 752 176 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH datain(63:8)
            WIRE 752 480 816 480
            BEGIN DISPLAY 752 480 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH datain(79:24)
            WIRE 752 784 816 784
            BEGIN DISPLAY 752 784 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH datain(87:32)
            WIRE 752 1088 816 1088
            BEGIN DISPLAY 752 1088 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH datain(95:40)
            WIRE 752 1392 816 1392
            BEGIN DISPLAY 752 1392 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH datain(103:48)
            WIRE 752 1712 816 1712
            BEGIN DISPLAY 752 1712 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH datain(111:56)
            WIRE 752 2032 816 2032
            BEGIN DISPLAY 752 2032 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        IOMARKER 208 496 datain(111:0) R180 28
        BEGIN BRANCH datain(111:0)
            WIRE 208 384 224 384
            WIRE 224 384 224 496
            WIRE 208 496 224 496
        END BRANCH
    END SHEET
END SCHEMATIC
