VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtex2p"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL a(55:0)
        SIGNAL b(55:0)
        SIGNAL amask(6:0)
        SIGNAL a(55:48)
        SIGNAL b(55:48)
        SIGNAL a(47:40)
        SIGNAL b(47:40)
        SIGNAL a(39:32)
        SIGNAL b(39:32)
        SIGNAL a(31:24)
        SIGNAL amask(3)
        SIGNAL a(7:0)
        SIGNAL b(15:8)
        SIGNAL b(23:16)
        SIGNAL XLXN_19
        SIGNAL XLXN_20
        SIGNAL XLXN_21
        SIGNAL XLXN_22
        SIGNAL XLXN_23
        SIGNAL XLXN_24
        SIGNAL XLXN_25
        SIGNAL XLXN_26
        SIGNAL XLXN_27
        SIGNAL XLXN_28
        SIGNAL XLXN_29
        SIGNAL XLXN_30
        SIGNAL XLXN_32
        SIGNAL amask(0)
        SIGNAL amask(1)
        SIGNAL amask(2)
        SIGNAL XLXN_38
        SIGNAL amask(4)
        SIGNAL amask(5)
        SIGNAL amask(6)
        SIGNAL match
        SIGNAL b(31:24)
        SIGNAL b(7:0)
        SIGNAL a(15:8)
        SIGNAL a(23:16)
        PORT Input a(55:0)
        PORT Input b(55:0)
        PORT Input amask(6:0)
        PORT Output match
        BEGIN BLOCKDEF comp8
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -384 320 -64 
            LINE N 384 -224 320 -224 
            RECTANGLE N 0 -332 64 -308 
            LINE N 0 -320 64 -320 
            RECTANGLE N 0 -140 64 -116 
            LINE N 0 -128 64 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF or2b1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 32 -64 
            CIRCLE N 32 -76 56 -52 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            LINE N 112 -48 48 -48 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -144 48 -144 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            ARC N 28 -224 204 -48 112 -48 192 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF and7
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -448 64 -64 
            ARC N 96 -304 192 -208 144 -208 144 -304 
            LINE N 64 -304 144 -304 
            LINE N 144 -208 64 -208 
            LINE N 256 -256 192 -256 
            LINE N 0 -448 64 -448 
            LINE N 0 -384 64 -384 
            LINE N 0 -320 64 -320 
            LINE N 0 -256 64 -256 
            LINE N 0 -192 64 -192 
            LINE N 0 -128 64 -128 
            LINE N 0 -64 64 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 comp8
            PIN A(7:0) a(55:48)
            PIN B(7:0) b(55:48)
            PIN EQ XLXN_19
        END BLOCK
        BEGIN BLOCK XLXI_2 comp8
            PIN A(7:0) a(47:40)
            PIN B(7:0) b(47:40)
            PIN EQ XLXN_20
        END BLOCK
        BEGIN BLOCK XLXI_3 comp8
            PIN A(7:0) a(39:32)
            PIN B(7:0) b(39:32)
            PIN EQ XLXN_21
        END BLOCK
        BEGIN BLOCK XLXI_4 comp8
            PIN A(7:0) a(31:24)
            PIN B(7:0) b(31:24)
            PIN EQ XLXN_22
        END BLOCK
        BEGIN BLOCK XLXI_5 comp8
            PIN A(7:0) a(23:16)
            PIN B(7:0) b(23:16)
            PIN EQ XLXN_25
        END BLOCK
        BEGIN BLOCK XLXI_6 comp8
            PIN A(7:0) a(15:8)
            PIN B(7:0) b(15:8)
            PIN EQ XLXN_24
        END BLOCK
        BEGIN BLOCK XLXI_7 comp8
            PIN A(7:0) a(7:0)
            PIN B(7:0) b(7:0)
            PIN EQ XLXN_23
        END BLOCK
        BEGIN BLOCK XLXI_8 or2b1
            PIN I0 amask(6)
            PIN I1 XLXN_19
            PIN O XLXN_38
        END BLOCK
        BEGIN BLOCK XLXI_9 or2b1
            PIN I0 amask(5)
            PIN I1 XLXN_20
            PIN O XLXN_32
        END BLOCK
        BEGIN BLOCK XLXI_10 or2b1
            PIN I0 amask(4)
            PIN I1 XLXN_21
            PIN O XLXN_30
        END BLOCK
        BEGIN BLOCK XLXI_11 or2b1
            PIN I0 amask(3)
            PIN I1 XLXN_22
            PIN O XLXN_29
        END BLOCK
        BEGIN BLOCK XLXI_12 or2b1
            PIN I0 amask(0)
            PIN I1 XLXN_23
            PIN O XLXN_26
        END BLOCK
        BEGIN BLOCK XLXI_13 or2b1
            PIN I0 amask(1)
            PIN I1 XLXN_24
            PIN O XLXN_28
        END BLOCK
        BEGIN BLOCK XLXI_14 or2b1
            PIN I0 amask(2)
            PIN I1 XLXN_25
            PIN O XLXN_27
        END BLOCK
        BEGIN BLOCK XLXI_15 and7
            PIN I0 XLXN_26
            PIN I1 XLXN_29
            PIN I2 XLXN_30
            PIN I3 XLXN_28
            PIN I4 XLXN_32
            PIN I5 XLXN_38
            PIN I6 XLXN_27
            PIN O match
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 512 704 R0
        INSTANCE XLXI_2 512 1232 R0
        INSTANCE XLXI_3 512 1744 R0
        INSTANCE XLXI_4 512 2304 R0
        INSTANCE XLXI_5 1552 832 R0
        INSTANCE XLXI_6 1552 1376 R0
        INSTANCE XLXI_7 1552 1936 R0
        BEGIN BRANCH a(55:0)
            WIRE 176 96 320 96
        END BRANCH
        IOMARKER 176 96 a(55:0) R180 28
        BEGIN BRANCH b(55:0)
            WIRE 176 176 320 176
        END BRANCH
        IOMARKER 176 176 b(55:0) R180 28
        BEGIN BRANCH amask(6:0)
            WIRE 1088 112 1360 112
        END BRANCH
        IOMARKER 1088 112 amask(6:0) R180 28
        BEGIN BRANCH a(55:48)
            WIRE 432 384 512 384
            BEGIN DISPLAY 432 384 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b(55:48)
            WIRE 432 576 512 576
            BEGIN DISPLAY 432 576 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH a(47:40)
            WIRE 432 912 512 912
            BEGIN DISPLAY 432 912 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b(47:40)
            WIRE 432 1104 512 1104
            BEGIN DISPLAY 432 1104 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH a(39:32)
            WIRE 432 1424 512 1424
            BEGIN DISPLAY 432 1424 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b(39:32)
            WIRE 432 1616 512 1616
            BEGIN DISPLAY 432 1616 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH a(31:24)
            WIRE 432 1984 512 1984
            BEGIN DISPLAY 432 1984 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b(31:24)
            WIRE 432 2176 512 2176
            BEGIN DISPLAY 432 2176 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b(7:0)
            WIRE 1472 1808 1552 1808
            BEGIN DISPLAY 1472 1808 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH a(7:0)
            WIRE 1472 1616 1552 1616
            BEGIN DISPLAY 1472 1616 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b(15:8)
            WIRE 1488 1248 1552 1248
            BEGIN DISPLAY 1488 1248 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH a(15:8)
            WIRE 1472 1056 1552 1056
            BEGIN DISPLAY 1472 1056 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH b(23:16)
            WIRE 1472 704 1552 704
            BEGIN DISPLAY 1472 704 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH a(23:16)
            WIRE 1472 512 1552 512
            BEGIN DISPLAY 1472 512 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_19
            WIRE 896 480 1056 480
        END BRANCH
        BEGIN BRANCH XLXN_20
            WIRE 896 1008 1056 1008
        END BRANCH
        BEGIN BRANCH XLXN_21
            WIRE 896 1520 1056 1520
        END BRANCH
        BEGIN BRANCH XLXN_22
            WIRE 896 2080 1040 2080
        END BRANCH
        BEGIN BRANCH XLXN_23
            WIRE 1936 1712 1968 1712
        END BRANCH
        INSTANCE XLXI_12 1968 1840 R0
        BEGIN BRANCH XLXN_24
            WIRE 1936 1152 2112 1152
        END BRANCH
        BEGIN BRANCH XLXN_25
            WIRE 1936 608 2128 608
        END BRANCH
        INSTANCE XLXI_15 2416 1440 R0
        BEGIN BRANCH XLXN_26
            WIRE 2224 1744 2416 1744
            WIRE 2416 1376 2416 1744
        END BRANCH
        BEGIN BRANCH XLXN_27
            WIRE 2384 640 2416 640
            WIRE 2416 640 2416 992
        END BRANCH
        BEGIN BRANCH XLXN_28
            WIRE 2368 1184 2416 1184
        END BRANCH
        BEGIN BRANCH XLXN_29
            WIRE 1296 2112 2400 2112
            WIRE 2400 1312 2416 1312
            WIRE 2400 1312 2400 2112
        END BRANCH
        BEGIN BRANCH amask(0)
            WIRE 1936 1776 1968 1776
            BEGIN DISPLAY 1936 1776 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_14 2128 736 R0
        INSTANCE XLXI_13 2112 1280 R0
        BEGIN BRANCH amask(1)
            WIRE 2048 1216 2112 1216
            BEGIN DISPLAY 2048 1216 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH amask(2)
            WIRE 2064 672 2128 672
            BEGIN DISPLAY 2064 672 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_11 1040 2208 R0
        INSTANCE XLXI_10 1056 1648 R0
        BEGIN BRANCH XLXN_30
            WIRE 1312 1552 1392 1552
            WIRE 1392 1552 1392 1936
            WIRE 1392 1936 2304 1936
            WIRE 2304 1264 2304 1936
            WIRE 2304 1264 2416 1264
            WIRE 2416 1248 2416 1264
        END BRANCH
        INSTANCE XLXI_9 1056 1136 R0
        BEGIN BRANCH XLXN_32
            WIRE 1312 1040 1376 1040
            WIRE 1376 912 1376 1040
            WIRE 1376 912 2400 912
            WIRE 2400 912 2400 1120
            WIRE 2400 1120 2416 1120
        END BRANCH
        INSTANCE XLXI_8 1056 608 R0
        BEGIN BRANCH XLXN_38
            WIRE 1312 512 1392 512
            WIRE 1392 512 1392 832
            WIRE 1392 832 1952 832
            WIRE 1952 832 1952 1056
            WIRE 1952 1056 2416 1056
        END BRANCH
        BEGIN BRANCH amask(3)
            WIRE 960 2144 1040 2144
            BEGIN DISPLAY 960 2144 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH amask(4)
            WIRE 960 1584 1056 1584
            BEGIN DISPLAY 960 1584 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH amask(5)
            WIRE 928 1072 1056 1072
            BEGIN DISPLAY 928 1072 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH amask(6)
            WIRE 944 544 1056 544
            BEGIN DISPLAY 944 544 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH match
            WIRE 2672 1184 2800 1184
        END BRANCH
        IOMARKER 2800 1184 match R0 28
    END SHEET
END SCHEMATIC
