The following files were generated for 'dual_port_mem' in directory 
C:\Documents and Settings\All Users\Documents\Lab2\Lab2\Lab3:

dual_port_mem.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

dual_port_mem.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

dual_port_mem.sym:
   Please see the core data sheet.

dual_port_mem.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

dual_port_mem.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

dual_port_mem.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

dual_port_mem.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

dual_port_mem.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

dual_port_mem_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

dual_port_mem_readme.txt:
   Text file indicating the files generated and how they are used.

dual_port_mem_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

