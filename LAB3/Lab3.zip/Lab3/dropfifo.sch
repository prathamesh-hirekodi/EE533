VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "virtex2p"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL firstword
        SIGNAL clk
        SIGNAL lastword
        SIGNAL waddr(7:0)
        SIGNAL rst
        SIGNAL XLXN_21
        SIGNAL in_fifo(71:0)
        SIGNAL in_fifo0(71:0)
        SIGNAL out_fifo(71:0)
        SIGNAL raddr(7:0)
        SIGNAL XLXN_33(7:0)
        SIGNAL XLXN_34
        SIGNAL XLXN_35
        SIGNAL XLXN_36
        SIGNAL XLXN_37
        SIGNAL XLXN_38
        SIGNAL XLXN_39
        SIGNAL XLXN_41
        SIGNAL XLXN_42
        SIGNAL fiforead
        SIGNAL XLXN_47
        SIGNAL valid_data
        SIGNAL drop_pkt
        SIGNAL fifowrite
        PORT Input firstword
        PORT Input clk
        PORT Input lastword
        PORT Input rst
        PORT Input in_fifo(71:0)
        PORT Output out_fifo(71:0)
        PORT Input fiforead
        PORT Output valid_data
        PORT Input drop_pkt
        PORT Input fifowrite
        BEGIN BLOCKDEF fd
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -320 320 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF fdc
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            RECTANGLE N 64 -320 320 -64 
            LINE N 64 -112 80 -128 
            LINE N 80 -128 64 -144 
            LINE N 192 -64 192 -32 
            LINE N 192 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF fd8ce
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            RECTANGLE N 320 -268 384 -244 
            RECTANGLE N 0 -268 64 -244 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF comp8
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -384 320 -64 
            LINE N 384 -224 320 -224 
            RECTANGLE N 0 -332 64 -308 
            LINE N 0 -320 64 -320 
            RECTANGLE N 0 -140 64 -116 
            LINE N 0 -128 64 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF or2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            LINE N 112 -144 48 -144 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -48 48 -48 
        END BLOCKDEF
        BEGIN BLOCKDEF and2b1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -48 64 -144 
            LINE N 64 -144 144 -144 
            LINE N 144 -48 64 -48 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 256 -96 192 -96 
            LINE N 0 -128 64 -128 
            LINE N 0 -64 40 -64 
            CIRCLE N 40 -76 64 -52 
        END BLOCKDEF
        BEGIN BLOCKDEF and3b2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 40 -64 
            CIRCLE N 40 -76 64 -52 
            LINE N 0 -128 40 -128 
            CIRCLE N 40 -140 64 -116 
            LINE N 0 -192 64 -192 
            LINE N 256 -128 192 -128 
            LINE N 64 -64 64 -192 
            ARC N 96 -176 192 -80 144 -80 144 -176 
            LINE N 144 -80 64 -80 
            LINE N 64 -176 144 -176 
        END BLOCKDEF
        BEGIN BLOCKDEF cb8cle
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -448 320 -64 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 0 -384 64 -384 
            RECTANGLE N 0 -396 64 -372 
            LINE N 384 -384 320 -384 
            LINE N 384 -192 320 -192 
            RECTANGLE N 320 -396 384 -372 
            LINE N 384 -128 320 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF reg9b
            TIMESTAMP 2026 1 31 23 47 48
            RECTANGLE N 64 -256 320 0 
            RECTANGLE N 0 -236 64 -212 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -236 384 -212 
            LINE N 320 -224 384 -224 
        END BLOCKDEF
        BEGIN BLOCKDEF cb8ce
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 384 -128 320 -128 
            RECTANGLE N 320 -268 384 -244 
            LINE N 384 -256 320 -256 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 384 -192 320 -192 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF dual_port_mem
            TIMESTAMP 2026 2 1 2 39 52
            RECTANGLE N 32 0 256 496 
            BEGIN LINE W 0 48 32 48 
            END LINE
            BEGIN LINE W 0 80 32 80 
            END LINE
            LINE N 0 112 32 112 
            LINE N 0 240 32 240 
            BEGIN LINE W 0 272 32 272 
            END LINE
            LINE N 0 464 32 464 
            BEGIN LINE W 256 272 288 272 
            END LINE
        END BLOCKDEF
        BEGIN BLOCKDEF dual_port_memory
            TIMESTAMP 2026 2 1 2 23 41
            RECTANGLE N 64 0 320 0 
        END BLOCKDEF
        BEGIN BLOCKDEF vcc
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -32 64 -64 
            LINE N 64 0 64 -32 
            LINE N 96 -64 32 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 fd
            PIN C clk
            PIN D firstword
            PIN Q XLXN_35
        END BLOCK
        BEGIN BLOCK XLXI_2 fd
            PIN C clk
            PIN D lastword
            PIN Q XLXN_34
        END BLOCK
        BEGIN BLOCK XLXI_3 fd
            PIN C clk
            PIN D drop_pkt
            PIN Q XLXN_47
        END BLOCK
        BEGIN BLOCK XLXI_4 fd
            PIN C clk
            PIN D fifowrite
            PIN Q XLXN_38
        END BLOCK
        BEGIN BLOCK XLXI_5 fdc
            PIN C clk
            PIN CLR rst
            PIN D XLXN_39
            PIN Q valid_data
        END BLOCK
        BEGIN BLOCK XLXI_6 fd8ce
            PIN C clk
            PIN CE XLXN_37
            PIN CLR rst
            PIN D(7:0) waddr(7:0)
            PIN Q(7:0) XLXN_33(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_7 comp8
            PIN A(7:0) waddr(7:0)
            PIN B(7:0) raddr(7:0)
            PIN EQ XLXN_42
        END BLOCK
        BEGIN BLOCK XLXI_8 comp8
            PIN A(7:0) raddr(7:0)
            PIN B(7:0) XLXN_33(7:0)
            PIN EQ XLXN_41
        END BLOCK
        BEGIN BLOCK XLXI_9 or2
            PIN I0 XLXN_34
            PIN I1 XLXN_35
            PIN O XLXN_36
        END BLOCK
        BEGIN BLOCK XLXI_10 and2b1
            PIN I0 XLXN_47
            PIN I1 XLXN_36
            PIN O XLXN_37
        END BLOCK
        BEGIN BLOCK XLXI_11 and3b2
            PIN I0 XLXN_41
            PIN I1 XLXN_42
            PIN I2 fiforead
            PIN O XLXN_39
        END BLOCK
        BEGIN BLOCK XLXI_12 cb8cle
            PIN C clk
            PIN CE XLXN_38
            PIN CLR rst
            PIN D(7:0) XLXN_33(7:0)
            PIN L XLXN_47
            PIN CEO
            PIN Q(7:0) waddr(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_13 reg9b
            PIN d(71:0) in_fifo(71:0)
            PIN clr rst
            PIN ce XLXN_21
            PIN clk clk
            PIN q(71:0) in_fifo0(71:0)
        END BLOCK
        BEGIN BLOCK XLXI_14 cb8ce
            PIN C clk
            PIN CE XLXN_39
            PIN CLR rst
            PIN CEO
            PIN Q(7:0) raddr(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_15 dual_port_mem
            PIN clka clk
            PIN clkb clk
            PIN wea XLXN_38
            PIN addra(7:0) waddr(7:0)
            PIN addrb(7:0) raddr(7:0)
            PIN dina(71:0) in_fifo0(71:0)
            PIN doutb(71:0) out_fifo(71:0)
        END BLOCK
        BLOCK XLXI_16 dual_port_memory
        BEGIN BLOCK XLXI_17 vcc
            PIN P XLXN_21
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 144 400 R0
        INSTANCE XLXI_2 144 800 R0
        INSTANCE XLXI_3 144 2736 R0
        INSTANCE XLXI_4 944 416 R0
        INSTANCE XLXI_5 1776 2240 R0
        INSTANCE XLXI_6 144 1296 R0
        INSTANCE XLXI_8 896 1920 R0
        INSTANCE XLXI_9 608 512 R0
        INSTANCE XLXI_10 992 640 R0
        INSTANCE XLXI_11 1392 1440 R0
        INSTANCE XLXI_12 1744 1024 R0
        BEGIN INSTANCE XLXI_13 2160 336 R0
        END INSTANCE
        INSTANCE XLXI_14 1760 1648 R0
        BEGIN INSTANCE XLXI_15 2608 880 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_16 2352 1728 R0
        END INSTANCE
        BEGIN BRANCH firstword
            WIRE 80 144 144 144
        END BRANCH
        IOMARKER 48 2608 clk R180 28
        BEGIN BRANCH clk
            WIRE 48 272 144 272
            WIRE 48 272 48 384
            WIRE 48 384 48 672
            WIRE 48 672 144 672
            WIRE 48 672 48 1168
            WIRE 48 1168 64 1168
            WIRE 64 1168 144 1168
            WIRE 64 1168 64 2224
            WIRE 64 2224 64 2608
            WIRE 64 2608 144 2608
            WIRE 64 2224 912 2224
            WIRE 48 384 544 384
            WIRE 48 2608 64 2608
            WIRE 544 288 544 384
            WIRE 544 288 912 288
            WIRE 912 288 944 288
            WIRE 912 288 912 896
            WIRE 912 896 1680 896
            WIRE 1680 896 1744 896
            WIRE 1680 896 1680 1120
            WIRE 1680 1120 1680 1520
            WIRE 1680 1520 1760 1520
            WIRE 1680 1120 2480 1120
            WIRE 2480 1120 2608 1120
            WIRE 2480 1120 2480 1344
            WIRE 2480 1344 2608 1344
            WIRE 912 2112 912 2224
            WIRE 912 2112 1776 2112
            WIRE 1680 304 2160 304
            WIRE 1680 304 1680 896
        END BRANCH
        IOMARKER 80 144 firstword R180 28
        BEGIN BRANCH lastword
            WIRE 80 544 144 544
        END BRANCH
        IOMARKER 80 544 lastword R180 28
        BEGIN BRANCH rst
            WIRE 144 1264 144 1888
            WIRE 144 1888 144 1904
            WIRE 144 1888 1760 1888
            WIRE 1760 1888 1760 2208
            WIRE 1760 2208 1776 2208
            WIRE 1616 176 1616 1056
            WIRE 1616 1056 1744 1056
            WIRE 1744 1056 1744 1632
            WIRE 1744 1632 1760 1632
            WIRE 1760 1632 1760 1888
            WIRE 1616 176 2160 176
            WIRE 1744 992 1744 1056
            WIRE 1760 1616 1760 1632
        END BRANCH
        INSTANCE XLXI_17 1888 112 R0
        BEGIN BRANCH XLXN_21
            WIRE 1952 112 1952 240
            WIRE 1952 240 2160 240
        END BRANCH
        BEGIN BRANCH in_fifo(71:0)
            WIRE 2064 112 2160 112
        END BRANCH
        BEGIN BRANCH in_fifo0(71:0)
            WIRE 2544 112 2704 112
            WIRE 2704 112 2704 816
            WIRE 2544 816 2544 960
            WIRE 2544 960 2608 960
            WIRE 2544 816 2704 816
            BEGIN DISPLAY 2704 112 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH out_fifo(71:0)
            WIRE 2896 1152 2944 1152
        END BRANCH
        IOMARKER 2944 1152 out_fifo(71:0) R0 28
        BEGIN BRANCH waddr(7:0)
            WIRE 80 896 592 896
            WIRE 592 896 592 1040
            WIRE 592 1040 848 1040
            WIRE 848 1040 848 2288
            WIRE 848 2288 2208 2288
            WIRE 848 1040 864 1040
            WIRE 864 1040 864 1072
            WIRE 864 1072 896 1072
            WIRE 80 896 80 960
            WIRE 80 960 80 1040
            WIRE 80 1040 144 1040
            WIRE 2128 640 2208 640
            WIRE 2208 640 2256 640
            WIRE 2256 640 2256 928
            WIRE 2256 928 2608 928
            WIRE 2208 640 2208 2288
            BEGIN DISPLAY 80 960 ATTR Name
                ALIGNMENT SOFT-TVCENTER
            END DISPLAY
            BEGIN DISPLAY 2256 640 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH raddr(7:0)
            WIRE 864 1472 880 1472
            WIRE 880 1472 880 1600
            WIRE 880 1600 896 1600
            WIRE 864 1472 864 2272
            WIRE 864 2272 2240 2272
            WIRE 880 1264 896 1264
            WIRE 880 1264 880 1360
            WIRE 880 1360 880 1472
            WIRE 2144 1392 2240 1392
            WIRE 2240 1392 2240 2272
            WIRE 2240 1152 2608 1152
            WIRE 2240 1152 2240 1392
            BEGIN DISPLAY 880 1360 ATTR Name
                ALIGNMENT SOFT-TVCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_33(7:0)
            WIRE 528 1040 576 1040
            WIRE 576 976 576 1040
            WIRE 576 976 688 976
            WIRE 688 640 688 976
            WIRE 688 640 1696 640
            WIRE 1696 640 1744 640
            WIRE 1696 640 1696 928
            WIRE 784 928 784 1792
            WIRE 784 1792 896 1792
            WIRE 784 928 1696 928
        END BRANCH
        BEGIN BRANCH XLXN_34
            WIRE 528 544 560 544
            WIRE 560 448 560 544
            WIRE 560 448 608 448
        END BRANCH
        BEGIN BRANCH XLXN_35
            WIRE 528 144 560 144
            WIRE 560 144 560 384
            WIRE 560 384 608 384
        END BRANCH
        BEGIN BRANCH XLXN_36
            WIRE 864 416 928 416
            WIRE 928 416 928 512
            WIRE 928 512 992 512
        END BRANCH
        BEGIN BRANCH XLXN_37
            WIRE 80 1104 144 1104
            WIRE 80 1104 80 1344
            WIRE 80 1344 1328 1344
            WIRE 1248 544 1328 544
            WIRE 1328 544 1328 1344
        END BRANCH
        BEGIN BRANCH XLXN_38
            WIRE 1328 160 1536 160
            WIRE 1536 160 1536 832
            WIRE 1536 832 1744 832
            WIRE 1536 832 1536 1040
            WIRE 1536 1040 2192 1040
            WIRE 2192 992 2192 1040
            WIRE 2192 992 2608 992
        END BRANCH
        IOMARKER 144 1904 rst R90 28
        BEGIN BRANCH XLXN_39
            WIRE 1648 1312 1696 1312
            WIRE 1696 1312 1696 1456
            WIRE 1696 1456 1760 1456
            WIRE 1696 1456 1696 1984
            WIRE 1696 1984 1776 1984
        END BRANCH
        BEGIN BRANCH XLXN_41
            WIRE 1280 1696 1328 1696
            WIRE 1328 1376 1328 1696
            WIRE 1328 1376 1392 1376
        END BRANCH
        BEGIN BRANCH XLXN_42
            WIRE 1280 1168 1376 1168
            WIRE 1376 1168 1376 1312
            WIRE 1376 1312 1392 1312
        END BRANCH
        INSTANCE XLXI_7 896 1392 R0
        IOMARKER 1392 1024 fiforead R180 28
        BEGIN BRANCH fiforead
            WIRE 1392 1024 1408 1024
            WIRE 1408 1024 1408 1232
            WIRE 1392 1232 1392 1248
            WIRE 1392 1232 1408 1232
        END BRANCH
        BEGIN BRANCH XLXN_47
            WIRE 528 2480 560 2480
            WIRE 560 912 560 2480
            WIRE 560 912 1504 912
            WIRE 928 576 992 576
            WIRE 928 576 928 768
            WIRE 928 768 1504 768
            WIRE 1504 768 1744 768
            WIRE 1504 768 1504 912
        END BRANCH
        BEGIN BRANCH valid_data
            WIRE 2160 1984 2336 1984
        END BRANCH
        IOMARKER 2336 1984 valid_data R0 28
        BEGIN BRANCH drop_pkt
            WIRE 128 2400 128 2480
            WIRE 128 2480 144 2480
        END BRANCH
        IOMARKER 128 2400 drop_pkt R270 28
        IOMARKER 2064 112 in_fifo(71:0) R180 28
        BEGIN BRANCH fifowrite
            WIRE 864 160 944 160
        END BRANCH
        IOMARKER 864 160 fifowrite R180 28
    END SHEET
END SCHEMATIC
